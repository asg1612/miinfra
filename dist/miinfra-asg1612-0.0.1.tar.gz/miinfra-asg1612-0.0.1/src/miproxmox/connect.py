# -*- coding: utf-8 -*-

"""

:copyright: (c) 2021 by Andrés Sánchez García.
:license: Apache2, see LICENSE for more details.
"""

def add_one(number):
    return number + 1